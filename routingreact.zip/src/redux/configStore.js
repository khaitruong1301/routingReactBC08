import {combineReducers, createStore} from 'redux';


const rootReducer = combineReducers({
    //Khai báo reducer
    
})


export const store = createStore(rootReducer)


